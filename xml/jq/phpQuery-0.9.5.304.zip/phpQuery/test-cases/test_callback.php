<?php
require_once('../phpQuery/phpQuery.php');
phpQuery::$debug = true;

// TODO